import { useEffect, useRef, useState } from "react";
import { electronicsCatalog } from "@/data_electronics";
import { MapView } from "@/components/Map";
import { beautyCatalog } from "@/data_beauty";
import { fashionCatalog } from "@/data_fashion";
import { mobileCatalog } from "@/data_mobiles";
import { shoppingCatalog } from "@/data_shopping";
import { Ambulance, ArrowLeft, ArrowRight, Banknote, Bookmark, BookOpen, BriefcaseBusiness, ChevronRight, Compass, Cpu, ExternalLink, Flame, Fuel, GraduationCap, Heart, Hotel, Hospital, LocateFixed, Loader2, MapPin, Newspaper, PackageOpen, Pill, Search, Shield, Shirt, Smartphone, Sparkles, Trophy, UsersRound, Wrench } from "lucide-react";

const benefits = [
  "One calm place for opportunities, products, and what matters next.",
  "Personalized signals without the noise of endless tabs.",
  "Save, compare, and return whenever inspiration strikes.",
];

const categories = [
  { name: "Internships", count: "3.4k", icon: BriefcaseBusiness, color: "bg-[#e8f2ea] text-[#3a7a72]" },
  { name: "Hackathons", count: "1.2k", icon: Trophy, color: "bg-[#fff0db] text-[#b6752b]" },
  { name: "Shopping", count: "8.7k", icon: Compass, color: "bg-[#eee8fa] text-[#7761a8]" },
  { name: "Jobs", count: "12k", icon: UsersRound, color: "bg-[#e5eef7] text-[#4c719a]" },
  { name: "Competitions", count: "860", icon: Trophy, color: "bg-[#f5e9d7] text-[#ad7731]" },
  { name: "Mobiles", count: "2.1k", icon: Smartphone, color: "bg-[#e4eef4] text-[#4d7c94]" },
  { name: "Electronics", count: "5.6k", icon: Cpu, color: "bg-[#e9e9f8] text-[#6d67a0]" },
  { name: "Fashion", count: "9.2k", icon: Shirt, color: "bg-[#f7e7ed] text-[#aa5f79]" },
  { name: "Daily news", count: "Live", icon: Newspaper, color: "bg-[#f8e8eb] text-[#b05c70]" },
  { name: "Daily needs", count: "4.8k", icon: PackageOpen, color: "bg-[#e7f1e6] text-[#58805b]" },
  { name: "Beauty", count: "3.7k", icon: Heart, color: "bg-[#f7e4ee] text-[#a45c80]" },
  { name: "Scholarships", count: "1.8k", icon: GraduationCap, color: "bg-[#e9edf9] text-[#5c6fa3]" },
  { name: "Courses", count: "Live", icon: BookOpen, color: "bg-[#f5e9d7] text-[#ad7731]" },
];

const nearbyCategories = [
  { name: "Hospitals", icon: Hospital, query: "amenity=hospital", label: "Hospitals" },
  { name: "Pharmacies", icon: Pill, query: "amenity=pharmacy", label: "Pharmacies" },
  { name: "Police stations", icon: Shield, query: "amenity=police", label: "Police stations" },
  { name: "Fire stations", icon: Flame, query: "amenity=fire_station", label: "Fire stations" },
  { name: "Emergency ambulances", icon: Ambulance, query: "emergency=ambulance", label: "Emergency ambulances" },
  { name: "Hotels", icon: Hotel, query: "tourism=hotel", label: "Hotels" },
  { name: "Fuel stations", icon: Fuel, query: "amenity=fuel", label: "Fuel stations" },
  { name: "ATMs", icon: Banknote, query: "amenity=atm", label: "ATMs" },
  { name: "Workshops", icon: Wrench, query: "shop=car_repair", label: "Workshops" },
];

const recommendations = [
  { label: "Internships", title: "Build your next chapter", detail: "Fresh roles matched to curious people who like to make things.", meta: "Updated today", tone: "bg-[#e8f2ea]" },
  { label: "Shopping", title: "Smart picks, less scrolling", detail: "Useful products selected for quality, value, and everyday joy.", meta: "48 new picks", tone: "bg-[#fff0db]" },
  { label: "Hackathons", title: "Find your next challenge", detail: "Competitions and communities where ideas become momentum.", meta: "12 closing soon", tone: "bg-[#eee8fa]" },
];

export const categoryProducts: Record<string, Array<{ title: string; detail: string; source: string; meta: string; url: string; group?: string }>> = {
  Internships: [
    { title: "Frontend Engineering Intern", detail: "Build polished product experiences with a fast-moving team.", source: "LinkedIn", meta: "Remote · Apply soon", url: "https://www.linkedin.com/jobs/" },
    { title: "Product Design Internship", detail: "Learn by shipping user-centered ideas from sketch to launch.", source: "Internshala", meta: "India · 3 months", url: "https://internshala.com/internships/" },
    { title: "AI Research Intern", detail: "Explore practical machine learning problems with experienced mentors.", source: "Wellfound", meta: "Hybrid · New", url: "https://wellfound.com/jobs" },
  ],
  Hackathons: [
    { title: "AI Innovation Challenge", detail: "Prototype a useful AI idea and compete for community recognition.", source: "Devpost", meta: "Online · Open now", url: "https://devpost.com/hackathons" },
    { title: "Build for Good Weekend", detail: "A focused weekend for teams solving meaningful everyday problems.", source: "HackerEarth", meta: "48 hours · Teams", url: "https://www.hackerearth.com/challenges/" },
    { title: "Campus Code Sprint", detail: "Turn a bold concept into a working demo with fellow builders.", source: "Unstop", meta: "Students · 2 weeks", url: "https://unstop.com/hackathons" },
  ],
  Shopping: shoppingCatalog.map((product) => ({
    title: product.title,
    detail: `${product.title} · ${product.group}. Verify specifications, variant, seller, and availability before purchase.`,
    source: product.source,
    meta: `${product.price} · ${product.source}`,
    url: product.url,
    group: product.group,
  })),
  Jobs: [
    { title: "Product Operations Associate", detail: "Coordinate teams and turn customer insight into action.", source: "Naukri", meta: "Full time · New", url: "https://www.naukri.com/" },
    { title: "Growth Marketing Manager", detail: "Own experiments that help a thoughtful product find its people.", source: "LinkedIn", meta: "Hybrid · 4.8 rating", url: "https://www.linkedin.com/jobs/" },
    { title: "Backend Developer", detail: "Design dependable services for a product used every day.", source: "Indeed", meta: "Remote · Apply soon", url: "https://in.indeed.com/" },
  ],
  Competitions: [
    { title: "National Innovation Contest", detail: "Present a practical idea that can make a measurable difference.", source: "Unstop", meta: "₹1L prize pool", url: "https://unstop.com/competitions" },
    { title: "Design Thinking Sprint", detail: "Solve a real brief and show the thinking behind your solution.", source: "Designhill", meta: "Open submissions", url: "https://www.designhill.com/" },
    { title: "Open Data Challenge", detail: "Use data to tell a compelling story about the world around us.", source: "Kaggle", meta: "Community · Global", url: "https://www.kaggle.com/competitions" },
  ],
  Mobiles: mobileCatalog.map((mobile) => ({
    title: mobile.title,
    detail: `${mobile.title} · ${mobile.group}. Verify storage, color, seller, and availability before purchase.`,
    source: mobile.source,
    meta: `${mobile.price} · ${mobile.source}`,
    url: mobile.url,
    group: mobile.group,
  })),
  Electronics: electronicsCatalog.map((product) => ({
    title: product.title,
    detail: `${product.title} · ${product.group}. Verify specifications, variant, seller, and availability before purchase.`,
    source: product.source,
    meta: `${product.price} · ${product.source}`,
    url: product.url,
    group: product.group,
  })),
  Fashion: fashionCatalog.map((product) => ({
    title: product.title,
    detail: `${product.title} listed with the uploaded Flipkart price reference. Verify size, color, seller, and availability before purchase.`,
    source: "Flipkart",
    meta: product.price,
    url: product.url,
  })),
  "Daily news": [
    { title: "Today’s essential brief", detail: "A concise read on the stories shaping India and the world.", source: "The Hindu", meta: "Updated today", url: "https://www.thehindu.com/" },
    { title: "Business & technology", detail: "The useful context behind markets, products, and innovation.", source: "Economic Times", meta: "Live coverage", url: "https://economictimes.indiatimes.com/" },
    { title: "Explainers worth your time", detail: "Clear reporting for complex topics and fast-moving events.", source: "The Indian Express", meta: "Editor’s pick", url: "https://indianexpress.com/" },
  ],
  "Daily needs": [
    { title: "Weekly grocery essentials", detail: "A practical basket for meals, cleaning, and the week ahead.", source: "BigBasket", meta: "Price checked", url: "https://www.bigbasket.com/" },
    { title: "Home organization kit", detail: "Small improvements that make everyday spaces feel lighter.", source: "Amazon India", meta: "Prime eligible", url: "https://www.amazon.in/s?k=home+organization" },
    { title: "Wellness restock", detail: "Daily-care basics selected for convenience and repeat value.", source: "Blinkit", meta: "Fast delivery", url: "https://blinkit.com/" },
  ],
  Beauty: beautyCatalog.map((product) => ({
    title: product.title,
    detail: `${product.title} · ${product.group}. Check ingredients, size, seller, and suitability before purchase.`,
    source: product.source,
    meta: `${product.price} · ${product.source}`,
    url: product.url,
    group: product.group,
  })),
  Scholarships: [
    { title: "National Scholarship Portal", detail: "Browse central and state scholarship opportunities in one place.", source: "Government of India", meta: "Official portal", url: "https://scholarships.gov.in/" },
    { title: "Future leaders fellowship", detail: "Support for students building impact through study and service.", source: "Buddy4Study", meta: "Applications open", url: "https://www.buddy4study.com/" },
    { title: "STEM excellence award", detail: "Funding and mentorship for ambitious science and technology learners.", source: "Vidyasaarathi", meta: "Check eligibility", url: "https://www.vidyasaarathi.co.in/" },
  ],
  Courses: [
    { title: "Foundations of Data Analysis", detail: "Build practical spreadsheet, SQL, and visualization skills for modern work.", source: "Coursera", meta: "Beginner · Self-paced", url: "https://www.coursera.org/courses?query=data%20analysis" },
    { title: "Python Programming Essentials", detail: "Learn the core language concepts needed to automate tasks and build projects.", source: "edX", meta: "Beginner · Online", url: "https://www.edx.org/learn/python" },
    { title: "Machine Learning Specialization", detail: "Understand model building, evaluation, and responsible AI foundations.", source: "DeepLearning.AI", meta: "Intermediate · Certificate", url: "https://www.deeplearning.ai/courses/machine-learning-specialization/" },
  ],
};

export const parsePrice = (value: string) => {
  const match = value.match(/₹([\d,]+)/);
  return match ? Number(match[1].replace(/,/g, "")) : null;
};

function CategoryView({ category, onBack, initialQuery = "" }: { category: string; onBack: () => void; initialQuery?: string }) {
  const [query, setQuery] = useState(initialQuery);
  const [source, setSource] = useState("all");
  const [group, setGroup] = useState("all");
  const [priceRange, setPriceRange] = useState("all");
  const [sort, setSort] = useState("relevance");
  const products = categoryProducts[category] ?? [];
  const sources = Array.from(new Set(products.map((product) => product.source))).sort();
  const groups = Array.from(new Set(products.map((product) => product.group).filter(Boolean) as string[])).sort();
  const filteredProducts = products
    .filter((product) => `${product.title} ${product.detail}`.toLowerCase().includes(query.toLowerCase()))
    .filter((product) => source === "all" || product.source === source)
    .filter((product) => group === "all" || product.group === group)
    .filter((product) => {
      if (priceRange === "all") return true;
      const price = parsePrice(product.meta);
      if (price === null) return true;
      if (priceRange === "under-20") return price < 20000;
      if (priceRange === "20-50") return price >= 20000 && price <= 50000;
      return price > 50000;
    })
    .sort((a, b) => {
      if (sort === "price-low") return (parsePrice(a.meta) ?? Number.MAX_SAFE_INTEGER) - (parsePrice(b.meta) ?? Number.MAX_SAFE_INTEGER);
      if (sort === "price-high") return (parsePrice(b.meta) ?? -1) - (parsePrice(a.meta) ?? -1);
      if (sort === "name") return a.title.localeCompare(b.title);
      return 0;
    });

  return (
    <main className="min-h-screen bg-[#111314] text-[#f7f3ec]">
      <header className="border-b border-[#f2bb68]/15 bg-[#111314]/90 px-6 py-5 backdrop-blur sm:px-10 lg:px-14"><div className="mx-auto flex max-w-[1320px] items-center justify-between gap-5"><button onClick={onBack} className="flex items-center gap-2 text-sm font-semibold text-[#f2bb68] transition hover:text-[#ffd28e]"><ArrowLeft size={17} /> Back to discovery</button><span className="hidden text-lg font-semibold tracking-[-.04em] sm:block">findora<span className="text-[#f2bb68]">.</span>AI</span><span className="text-xs font-bold uppercase tracking-[.15em] text-white/35">{category}</span></div></header>
      <div className="mx-auto max-w-[1320px] px-6 py-10 sm:px-10 lg:px-14 lg:py-14">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Inside category</p><h1 className="mt-2 text-4xl font-semibold tracking-[-.06em] text-white sm:text-6xl">{category}</h1><p className="mt-4 text-sm text-white/50">Explore, compare, and open the original source for each listing.</p></div>{category !== "Mobiles" && <p className="text-sm font-semibold text-white/45">Showing {filteredProducts.length} of {products.length}</p>}</div>
        <div className="mt-9 grid gap-3 rounded-2xl border border-white/10 bg-[#171918] p-3 shadow-sm md:grid-cols-[1.5fr_1fr_1fr_1fr_1fr]"><label className="flex items-center gap-3 rounded-xl border border-[#f2bb68]/15 bg-[#111314] px-4 py-3 text-sm text-white/45"><Search size={16} className="text-[#f2bb68]" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Search ${category.toLowerCase()}...`} className="min-w-0 flex-1 bg-transparent text-white outline-none placeholder:text-white/35" /></label><select value={source} onChange={(event) => setSource(event.target.value)} className="rounded-xl bg-[#111314] px-4 py-3 text-sm font-medium text-white/65 outline-none"><option value="all">All sources</option>{sources.map((item) => <option key={item} value={item}>{item}</option>)}</select>{groups.length > 0 && <select value={group} onChange={(event) => setGroup(event.target.value)} className="rounded-xl bg-[#111314] px-4 py-3 text-sm font-medium text-white/65 outline-none"><option value="all">All mobile categories</option>{groups.map((item) => <option key={item} value={item}>{item}</option>)}</select>}<select value={priceRange} onChange={(event) => setPriceRange(event.target.value)} className="rounded-xl bg-[#111314] px-4 py-3 text-sm font-medium text-white/65 outline-none"><option value="all">All price ranges</option><option value="under-20">Under ₹20,000</option><option value="20-50">₹20,000–₹50,000</option><option value="over-50">Over ₹50,000</option></select><select value={sort} onChange={(event) => setSort(event.target.value)} className="rounded-xl bg-[#111314] px-4 py-3 text-sm font-medium text-white/65 outline-none"><option value="relevance">Sort: Relevance</option><option value="name">Sort: Name</option><option value="price-low">Sort: Price low to high</option><option value="price-high">Sort: Price high to low</option></select></div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{filteredProducts.map((product) => <article key={`${product.title}-${product.meta}`} className="group flex min-h-[225px] flex-col rounded-[1.35rem] border border-white/10 bg-[#171918] p-5 shadow-sm transition hover:-translate-y-1 hover:border-[#f2bb68]/40 hover:shadow-xl"><div className="flex items-start justify-between gap-4"><span className="rounded-full bg-[#2a2215] px-3 py-1 text-[10px] font-bold uppercase tracking-[.15em] text-[#f2bb68]">{product.source}</span><Bookmark size={17} className="text-white/25" /></div><h2 className="mt-7 text-lg font-semibold tracking-[-.03em] text-white">{product.title}</h2><p className="mt-2 flex-1 text-sm leading-6 text-white/55">{product.detail}</p><div className="mt-5 flex items-center justify-between gap-3 border-t border-white/10 pt-4"><span className="text-xs font-semibold text-white/45">{product.meta}</span><a href={product.url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs font-bold text-[#f2bb68] transition hover:text-[#ffd28e]">Open source <ExternalLink size={13} /></a></div></article>)}</div>
        {filteredProducts.length === 0 && <div className="mt-8 rounded-2xl border border-dashed border-[#f2bb68]/30 bg-[#171918] p-12 text-center"><h2 className="text-xl font-semibold text-white">No matches found</h2><p className="mt-2 text-sm text-white/50">Try a different search or clear one of the filters.</p></div>}
      </div>
    </main>
  );
}

type NearbyPlace = { id: string; name: string; address: string; lat: number; lon: number; distanceKm: number };

function NearbyView({ place, onBack }: { place: typeof nearbyCategories[number]; onBack: () => void }) {
  const [places, setPlaces] = useState<NearbyPlace[]>([]);
  const [status, setStatus] = useState<"idle" | "locating" | "loading" | "ready" | "error">("idle");
  const [message, setMessage] = useState(`Allow location access to find nearby ${place.label.toLowerCase()}.`);

  const findPlaces = () => {
    if (!navigator.geolocation) {
      setStatus("error");
      setMessage("Location is not supported by this browser.");
      return;
    }
    setStatus("locating");
    setMessage("Please allow your current location in the browser prompt…");
    navigator.geolocation.getCurrentPosition(async ({ coords }) => {
      const { latitude, longitude } = coords;
      const radiusMeters = 30000;
      const query = `[out:json][timeout:30];nwr[${place.query}](around:${radiusMeters},${latitude},${longitude});out center tags;`;
      setStatus("loading");
      setMessage(`Finding ${place.label.toLowerCase()} near your current location…`);
      try {
        const response = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`);
        if (!response.ok) throw new Error("The live nearby dataset is temporarily unavailable.");
        const data = await response.json() as { elements?: Array<{ id: number; type?: string; lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string> }> };
        const earthRadius = 6371;
        const toRadians = (value: number) => value * Math.PI / 180;
        const results = (data.elements ?? []).map((element) => {
          const lat = element.lat ?? element.center?.lat;
          const lon = element.lon ?? element.center?.lon;
          if (lat === undefined || lon === undefined) return null;
          const dLat = toRadians(lat - latitude);
          const dLon = toRadians(lon - longitude);
          const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(latitude)) * Math.cos(toRadians(lat)) * Math.sin(dLon / 2) ** 2;
          return {
            id: `${element.type ?? "place"}-${element.id}`,
            name: element.tags?.name ?? `Unnamed ${place.label.toLowerCase().replace(/s$/, "")}`,
            address: [element.tags?.['addr:street'], element.tags?.['addr:city']].filter(Boolean).join(", ") || "Address unavailable",
            lat,
            lon,
            distanceKm: earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)),
          };
        }).filter((item): item is NearbyPlace => item !== null)
          .sort((a, b) => a.distanceKm - b.distanceKm)
          .filter((item, index, list) => list.findIndex((candidate) => candidate.name === item.name) === index)
          .slice(0, 30);
        setPlaces(results);
        setStatus("ready");
        setMessage(results.length ? `Showing ${results.length} ${place.label.toLowerCase()} near your current location.` : `No ${place.label.toLowerCase()} were found in the nearby search area.`);
      } catch (error) {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "Unable to load nearby places right now.");
      }
    }, () => {
      setStatus("error");
      setMessage("Location permission was denied. Allow location access and try again.");
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 });
  };

  return (
    <main className="min-h-screen bg-[#111314] text-[#f7f3ec]">
      <header className="border-b border-[#f2bb68]/15 bg-[#111314]/90 px-6 py-5 backdrop-blur sm:px-10 lg:px-14"><div className="mx-auto flex max-w-[1320px] items-center justify-between gap-5"><button onClick={onBack} className="flex items-center gap-2 text-sm font-semibold text-[#f2bb68] transition hover:text-[#ffd28e]"><ArrowLeft size={17} /> Back to discovery</button><span className="hidden text-lg font-semibold tracking-[-.04em] sm:block">findora<span className="text-[#f2bb68]">.</span>AI</span><span className="text-xs font-bold uppercase tracking-[.15em] text-white/35">Find near me</span></div></header>
      <div className="mx-auto max-w-[1320px] px-6 py-10 sm:px-10 lg:px-14 lg:py-14">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Live location search</p><h1 className="mt-2 text-4xl font-semibold tracking-[-.06em] text-white sm:text-6xl">Nearby {place.label}</h1><p className="mt-4 max-w-2xl text-sm leading-6 text-white/50">We ask for your current location only for this search, then show nearby results from live OpenStreetMap data.</p></div><button onClick={findPlaces} disabled={status === "locating" || status === "loading"} className="flex items-center justify-center gap-2 rounded-xl bg-[#f2bb68] px-5 py-3 text-sm font-bold text-[#111314] transition hover:bg-[#ffd28e] disabled:cursor-wait disabled:opacity-70">{status === "locating" || status === "loading" ? <Loader2 size={16} className="animate-spin" /> : <LocateFixed size={16} />} {status === "ready" ? "Refresh nearby results" : "Use my current location"}</button></div>
        <div className="mt-9 flex items-start gap-3 rounded-2xl border border-[#f2bb68]/20 bg-[#171918] p-5 text-sm text-white/60"><MapPin size={18} className="mt-0.5 shrink-0 text-[#f2bb68]" /><p>{message}</p></div>
        {places.length > 0 && <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{places.map((item) => <article key={item.id} className="flex min-h-[200px] flex-col rounded-[1.35rem] border border-white/10 bg-[#171918] p-5 shadow-sm transition hover:-translate-y-1 hover:border-[#f2bb68]/40 hover:shadow-xl"><span className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-[#f2bb68]"><MapPin size={14} /> {item.distanceKm.toFixed(1)} km away</span><h2 className="mt-5 text-lg font-semibold text-white">{item.name}</h2><p className="mt-2 flex-1 text-sm leading-6 text-white/55">{item.address}</p><a href={`https://www.google.com/maps/search/?api=1&query=${item.lat},${item.lon}`} target="_blank" rel="noreferrer" className="mt-5 flex items-center gap-1 border-t border-white/10 pt-4 text-xs font-bold text-[#f2bb68] transition hover:text-[#ffd28e]">Open in Maps <ExternalLink size={13} /></a></article>)}</div>}
      </div>
    </main>
  );
}

function FindWhereIAm() {
  const [tracking, setTracking] = useState(false);
  const [coords, setCoords] = useState<{ latitude: number; longitude: number; accuracy: number } | null>(null);
  const [address, setAddress] = useState("");
  const [message, setMessage] = useState("Allow location access to see your live location.");
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.marker.AdvancedMarkerElement | null>(null);

  const syncMapLocation = (map: google.maps.Map, current: { latitude: number; longitude: number }) => {
    const position = { lat: current.latitude, lng: current.longitude };
    map.panTo(position);
    if (!markerRef.current) {
      markerRef.current = new google.maps.marker.AdvancedMarkerElement({ map, position, title: "Your live location" });
    } else {
      markerRef.current.position = position;
    }
  };

  useEffect(() => {
    if (!tracking) return;
    if (!navigator.geolocation) {
      setMessage("Location is not supported by this browser.");
      setTracking(false);
      return;
    }
    setMessage("Please allow location access in the browser prompt…");
    const watchId = navigator.geolocation.watchPosition(async ({ coords: current }) => {
      setCoords({ latitude: current.latitude, longitude: current.longitude, accuracy: current.accuracy });
      if (mapRef.current) syncMapLocation(mapRef.current, current);
      setMessage("Live location is active.");
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${current.latitude}&lon=${current.longitude}&zoom=18&addressdetails=1`);
        if (response.ok) {
          const data = await response.json() as { display_name?: string };
          setAddress(data.display_name ?? "Current area identified");
        }
      } catch {
        setAddress("Current coordinates available; area name is temporarily unavailable.");
      }
    }, () => {
      setMessage("Location permission was denied. Allow location access and try again.");
      setTracking(false);
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 });
    return () => navigator.geolocation.clearWatch(watchId);
  }, [tracking]);

  return <section className="mt-10 rounded-[1.5rem] border border-[#f2bb68]/20 bg-[#171918] p-6 shadow-sm sm:p-7"><div className="flex flex-col justify-between gap-5 md:flex-row md:items-center"><div><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-[#2a2215] text-[#f2bb68]"><LocateFixed size={19} /></span><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Find where I am</p><h2 className="mt-1 text-xl font-semibold text-white">Your live location</h2></div></div><p className="mt-4 max-w-2xl text-sm leading-6 text-white/55">Use your device location to see your current area and coordinates. Location is used only in your browser for this live view; no camera is required.</p></div><button onClick={() => setTracking((value) => !value)} className={`flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition ${tracking ? "border border-[#f2bb68]/40 bg-transparent text-[#f2bb68] hover:bg-[#2a2215]" : "bg-[#f2bb68] text-[#111314] hover:bg-[#ffd28e]"}`}>{tracking ? "Stop live tracking" : "Allow current location"}</button></div><div className="mt-5 flex items-start gap-3 rounded-xl border border-white/10 bg-[#111314] p-4 text-sm text-white/60"><MapPin size={17} className="mt-0.5 shrink-0 text-[#f2bb68]" /><div><p>{message}</p>{coords && <p className="mt-2 font-mono text-xs text-white/45">{coords.latitude.toFixed(6)}, {coords.longitude.toFixed(6)} · ±{Math.round(coords.accuracy)}m</p>}{address && <p className="mt-2 text-xs text-[#f2bb68]/75">{address}</p>}</div></div>{coords && <div className="mt-5 overflow-hidden rounded-2xl border border-white/10"><MapView className="h-[360px]" initialCenter={{ lat: coords.latitude, lng: coords.longitude }} initialZoom={15} onMapReady={(map) => { mapRef.current = map; syncMapLocation(map, coords); }} /></div>}</section>;
}

function DiscoverHome() {
  const [selectedCategory, setSelectedCategory] = useState("Internships");
  const [categoryView, setCategoryView] = useState<string | null>(null);
  const [nearbyView, setNearbyView] = useState<typeof nearbyCategories[number] | null>(null);
  const [categoryQuery, setCategoryQuery] = useState("");
  const [mainQuery, setMainQuery] = useState("");

  if (nearbyView) {
    return <NearbyView place={nearbyView} onBack={() => setNearbyView(null)} />;
  }
  if (categoryView) {
    return <CategoryView category={categoryView} initialQuery={categoryQuery} onBack={() => { setCategoryQuery(""); setCategoryView(null); }} />;
  }

  return (
    <main className="min-h-screen bg-[#111314] text-[#f7f3ec]">
      <header className="border-b border-[#f2bb68]/15 bg-[#111314]/90 px-6 py-5 backdrop-blur sm:px-10 lg:px-14">
        <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-6">
          <div className="flex items-center gap-3"><div className="grid size-10 place-items-center rounded-2xl bg-[#f2bb68] text-[#111314]"><Sparkles size={18} /></div><span className="text-lg font-semibold tracking-[-.04em]">findora<span className="text-[#f2bb68]">.</span>AI</span></div>
        </div>
      </header>
      <div className="mx-auto max-w-[1320px] px-6 py-10 sm:px-10 lg:px-14 lg:py-14">
        <section className="grid items-end gap-8 lg:grid-cols-[1fr_auto]"><div><p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Your discovery desk</p><h1 className="max-w-2xl text-4xl font-semibold leading-[1.05] tracking-[-.06em]">A smarter starting point for <span className="text-[#f2bb68]">what’s next.</span></h1><p className="mt-5 max-w-xl text-base leading-7 text-white/60">Explore the opportunities, products, and signals worth your attention today.</p></div><div className="flex flex-col gap-3"><form onSubmit={(event) => { event.preventDefault(); const normalized = mainQuery.trim().toLowerCase(); if (!normalized) return; const match = Object.entries(categoryProducts).find(([, products]) => products.some((product) => `${product.title} ${product.detail}`.toLowerCase().includes(normalized))); if (match) { setSelectedCategory(match[0]); setCategoryQuery(mainQuery.trim()); setCategoryView(match[0]); } }} className="flex w-full min-w-[280px] items-center gap-3 rounded-full border border-[#f2bb68]/35 bg-[#171918] px-4 py-3 text-sm text-white/50 shadow-[0_0_30px_rgba(242,187,104,.08)]"><Search size={16} className="text-[#f2bb68]" /><input value={mainQuery} onChange={(event) => setMainQuery(event.target.value)} placeholder="Search opportunities, products, news..." aria-label="Search Findora" className="min-w-0 flex-1 bg-transparent text-white outline-none placeholder:text-white/35" /></form><button className="group flex items-center justify-center gap-2 rounded-full bg-[#f2bb68] px-5 py-3 text-sm font-semibold text-[#111314] transition hover:bg-[#ffd28e]">Explore everything <ArrowRight size={16} className="transition group-hover:translate-x-1" /></button></div></section>
        <section className="mt-12"><div className="mb-4 flex items-center gap-3"><span className="h-px w-8 bg-[#f2bb68]" /><h2 className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Find near me</h2></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{nearbyCategories.map(({ name: place, icon: Icon, label }) => <button key={place} onClick={() => setNearbyView(nearbyCategories.find((item) => item.name === place) ?? null)} aria-label={`Find nearby ${label}`} className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-[#171918] p-4 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#f2bb68]/50 hover:shadow-lg"><span className="grid size-11 place-items-center rounded-xl bg-[#2a2215] text-[#f2bb68]"><Icon size={20} /></span><span className="flex-1"><strong className="block text-sm text-white">{place}</strong><span className="text-xs text-[#f2bb68]/55">Use current location</span></span><ChevronRight size={17} className="text-white/25 transition group-hover:translate-x-1 group-hover:text-[#f2bb68]" /></button>)}</div></section>
        <FindWhereIAm />
        <section className="mt-12"><div className="mb-4 flex items-center gap-3"><span className="h-px w-8 bg-[#f2bb68]" /><h2 className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Categories</h2></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{categories.map(({ name: category, count, icon: Icon }) => <button key={category} onClick={() => { setSelectedCategory(category); setCategoryView(category); }} aria-label={`Open ${category}`} aria-pressed={selectedCategory === category} className={`group flex items-center gap-4 rounded-2xl border p-4 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg ${selectedCategory === category ? "border-[#f2bb68] bg-[#2a2215] ring-2 ring-[#f2bb68]/20" : "border-white/10 bg-[#171918]"}`}><span className="grid size-11 place-items-center rounded-xl bg-[#2a2215] text-[#f2bb68]"><Icon size={20} /></span><span className="flex-1"><strong className="block text-sm text-white">{category}</strong><span className="text-xs text-[#f2bb68]/55">{count} to explore</span></span><ChevronRight size={17} className="text-white/25 transition group-hover:translate-x-1 group-hover:text-[#f2bb68]" /></button>)}</div></section>
        <section className="mt-16"><div className="mb-6 flex items-end justify-between"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">Curated for you</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em] text-white">Keep your curiosity moving.</h2></div><button className="hidden items-center gap-2 text-sm font-semibold text-[#f2bb68] sm:flex">View all <ExternalLink size={14} /></button></div><div className="grid gap-5 lg:grid-cols-3">{recommendations.map((item) => <article key={item.title} className="group rounded-[1.5rem] border border-white/10 bg-[#171918] p-6 transition hover:-translate-y-1 hover:border-[#f2bb68]/40 hover:shadow-xl"><div className="flex items-center justify-between"><span className="rounded-full bg-[#2a2215] px-3 py-1 text-[10px] font-bold uppercase tracking-[.15em] text-[#f2bb68]">{item.label}</span><button aria-label={`Save ${item.title}`} className="text-white/35 transition hover:text-[#f2bb68]"><Bookmark size={18} /></button></div><h3 className="mt-12 text-2xl font-semibold tracking-[-.05em] text-white">{item.title}</h3><p className="mt-3 min-h-14 text-sm leading-6 text-white/55">{item.detail}</p><div className="mt-6 flex items-center justify-between text-xs font-semibold text-white/45"><span>{item.meta}</span><span className="flex items-center gap-1 text-[#f2bb68]">Open <ArrowRight size={13} /></span></div></article>)}</div></section>
        <section className="mt-16 rounded-[1.75rem] border border-[#f2bb68]/20 bg-[#171918] p-7 text-white sm:p-10"><div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#f2bb68]">One search. More of what matters.</p><h2 className="mt-3 max-w-xl text-3xl font-semibold tracking-[-.05em]">Ask Findora anything.</h2><p className="mt-3 max-w-lg text-sm leading-6 text-white/55">Search across categories and let the useful connections come to you.</p></div><button className="flex items-center gap-2 self-start rounded-xl bg-[#f2bb68] px-5 py-3 text-sm font-bold text-[#111314] transition hover:bg-[#ffd28e] sm:self-auto">Start a search <ArrowRight size={16} /></button></div></section>
      </div>
    </main>
  );
}

export default function Home() {
  return <DiscoverHome />;
}
