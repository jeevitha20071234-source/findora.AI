import { describe, expect, it } from "vitest";
import { categoryProducts, parsePrice } from "../client/src/pages/Home";

describe("category listings", () => {
  it("provides curated results and source links for every category", () => {
    const categories = [
      "Internships",
      "Hackathons",
      "Shopping",
      "Jobs",
      "Competitions",
      "Mobiles",
      "Electronics",
      "Fashion",
      "Daily news",
      "Daily needs",
      "Beauty",
      "Scholarships",
      "Courses",
    ];

    expect(Object.keys(categoryProducts)).toEqual(categories);
    for (const category of categories) {
      expect(categoryProducts[category]).toHaveLength(category === "Mobiles" ? 900 : category === "Electronics" ? 400 : category === "Fashion" ? 300 : category === "Shopping" ? 398 : category === "Beauty" ? 400 : category === "Courses" ? 3 : 3);
      expect(categoryProducts[category].every((item) => item.title && item.detail && item.url.startsWith("https://"))).toBe(true);
    }
    expect(categoryProducts.Mobiles.filter((item) => item.source === "Amazon")).toHaveLength(225);
    expect(categoryProducts.Mobiles.filter((item) => item.source === "Flipkart")).toHaveLength(225);
    expect(categoryProducts.Mobiles.filter((item) => item.source === "Meesho")).toHaveLength(225);
    expect(categoryProducts.Mobiles.filter((item) => item.source === "Shopsy by Flipkart")).toHaveLength(225);
    expect(categoryProducts.Mobiles.every((item) => item.group)).toBe(true);
    expect(categoryProducts.Electronics.filter((item) => item.source === "Amazon")).toHaveLength(100);
    expect(categoryProducts.Electronics.filter((item) => item.source === "Flipkart")).toHaveLength(100);
    expect(categoryProducts.Electronics.filter((item) => item.source === "Meesho")).toHaveLength(100);
    expect(categoryProducts.Electronics.filter((item) => item.source === "Shopsy by Flipkart")).toHaveLength(100);
    expect(categoryProducts.Electronics.every((item) => item.group)).toBe(true);
    expect(categoryProducts.Shopping.filter((item) => item.source === "Amazon")).toHaveLength(99);
    expect(categoryProducts.Shopping.filter((item) => item.source === "Flipkart")).toHaveLength(100);
    expect(categoryProducts.Shopping.filter((item) => item.source === "Meesho")).toHaveLength(99);
    expect(categoryProducts.Shopping.filter((item) => item.source === "Shopsy by Flipkart")).toHaveLength(100);
    expect(categoryProducts.Shopping.every((item) => item.group)).toBe(true);
    expect(categoryProducts.Beauty.filter((item) => item.source === "Amazon")).toHaveLength(100);
    expect(categoryProducts.Beauty.filter((item) => item.source === "Flipkart")).toHaveLength(100);
    expect(categoryProducts.Beauty.filter((item) => item.source === "Meesho")).toHaveLength(100);
    expect(categoryProducts.Beauty.filter((item) => item.source === "Shopsy by Flipkart")).toHaveLength(100);
    expect(categoryProducts.Beauty.every((item) => item.group)).toBe(true);
  });

  it("parses Indian rupee prices for filtering and sorting", () => {
    expect(parsePrice("₹1,29,999")).toBe(129999);
    expect(parsePrice("Updated today")).toBeNull();
  });
});
